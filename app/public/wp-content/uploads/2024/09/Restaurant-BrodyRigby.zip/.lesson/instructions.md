PROJECT: Restaurant Grand Opening!

Instructions: Your video game history webpage has been a huge success. So now there are three restaurant owners that want you to develop their website! For this project, you will choose one of the restaurant’s below and develop their homepage using the information they provide.

Mondo Vecchio Pizzeria
Description: A pizza joint with old world style
Website Address: www.vecchiopizza.com
Address: 312 S. Main St., Fall River, MA
Email: admin@vecchiopizza.com
Phone: (508) 555-2341
Hours of Operation
Sunday: 11am – 5pm
Monday: Closed
Tuesday-Wednesday: 11am – 9pm
Thursday-Sat: 11am – 2am

Cascadas Taqueria
Description: A modern Mexican restaurant specializing in tacos and burritos
Website Address: cascadas.com
Address: 284 Faunce Corner Rd., Dartmouth, MA
Email: info@cascadas.com
Phone: (774) 555-9012
Hours of Operation
Sunday-Monday: Closed
Tuesday-Wednesday: 12pm –11:30pm
Thursday-Sat: 11am – 1am

Burger Shack
Description: Old school, greasy and delicious burgers are our specialty
Website Address: burgershack.com
Address: 122 Purchase St., New Bedford, MA
Email: eatburgers@burgershack.com
Phone: (508) 955-3999
Hours of Operation
Sunday: 12pm – 6pm
Monday-Wednesday: 11am – 10pm
Thursday: 11am – 1am

Specifications: Each restaurant owner has given you complete creative control over their homepage. This includes the creation of a logo, color scheme, and content layout. However, they do have some requirements about the homepage content.

Homepage Design
Create a logo for your restaurant using GIMP, do your best
Determine a color scheme (e.g., text and background colors) using theDesign School’s 50 website color schemes

Homepage Content: The webpage will contain…
  The name of the restaurant
  The logo you created
  Three pictures of the types of food served at the restaurant(no links to web pages)
  hyperlink to the Old Colony CIS department
  Owner’s restaurant description
  Contact information
  Address
  Phone number
  Website address 
  Hours of operation

Criteria for Success: Your restaurant homepage will…
Be a HTML document that… 
Is named “index.html”
Adheres to HTML syntax
Contain all content requested by the owner of your chosen restaurant
Use the following HTML elements in appropriate contexts…
  A title element (Contains name of lab)
  A style element (colors)
  A heading 1 element
  At least 3 heading 2 elements
  At least 3 paragraph elements
  At least 2 emphasis and/or strong elements
  Include at least 3 CSS rules to change formatting on the homepage 

Submission: Submit in replit and google classroom

