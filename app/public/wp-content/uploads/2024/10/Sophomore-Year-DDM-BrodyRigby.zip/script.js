//Variable controlling the path that the story is on.
var controlVar = "start";

//
function updateStory() {
  var finalAnswer = storyOutput;
  document.getElementById("story").innerHTML = finalAnswer;
}

//
var storyOutput = "Hey! This is an interactive story. Do you want to take part? Enter YES or NO.";
updateStory();

//
document.getElementById("javascriptButton").onclick = function interpretAnswer() {
	var inputResults = document.getElementById("answerField").value;
  answer = inputResults.toUpperCase();
	
  if (controlVar == "start") {
    checkAnswerStart();
  } else if (controlVar == "yes") {
    checkAnswerYes();
  } else if (controlVar == "continue1") {
    checkAnswerContinue1();
  } else if (controlVar == "left") {
    checkAnswerLeft();
  } else if (controlVar == "right") {
    checkAnswerRight();
  } else if (controlVar == "investigate1") {
    checkAnswerInvestigate1();
  } else if (controlVar == "enter") {
    checkAnswerEnter();
  } else if (controlVar == "inside") {
    checkAnswerInside();
  } else if (controlVar == "observe") {
    checkAnswerObserve();
  } else if (controlVar == "ignore") {
    checkAnswerIgnore();
  } else if (controlVar == "investigate2") {
    checkAnswerInvestigate2();
  }
};

//Start - Yes / No
function checkAnswerStart() {
  if (answer === "YES") {
    storyOutput = "You walk into the woods, do you want to RUN, or CONTINUE?";
    controlVar = "yes";
  } else if (answer === "NO") {
    storyOutput = "Aw! Okay. See you later. The end, you got the LAZY ENDING.";
    controlVar = "start";
  } else {
    // With no results, or bad results, repeat the question with more detail:
    storyOutput = "Hey! This is an interactive story. Do you want to take part? Enter YES or NO.";
  }
  updateStory();
}

//Yes - Run / Continue
function checkAnswerYes() {
  if (answer === "CONTINUE") {
    storyOutput = "You come to a split in the woods. There are two paths. Do you want to take the LEFT path or the RIGHT path?";
    controlVar = "continue1";
  } else if (answer === "RUN") {
    storyOutput = "You run away, all cowardly. You should go in that corner over there and think about all the fun you could have had. The end, you got the COWARD ENDING.";
    controlVar = "start";
  } else {
    // With no results, or bad results, repeat the question with more detail:
    storyOutput = "You walk into the woods, do you want to RUN, or CONTINUE?";
  }
  updateStory();
}

//Continue - Right / Left
function checkAnswerContinue1() {
  if (answer === "LEFT") {
    storyOutput = "You decide to take the LEFT path. The dirt road soon turns into a crunchy path of shiny gravel. It feels a little wet beneath your bare feet. Soothing, in a way. But this feeling of relaxation doesn’t last long, being replaced by a feeling of curiosity as you come across what looks to be a small village filled with busy people. You can’t shake the feeling that something is wrong. Do you want to ENTER the village, or stay where you are and see if you can OBSERVE anything suspicious?";
    controlVar = "left";
  } else if (answer === "RIGHT") {
    storyOutput = "You decide to go down the RIGHT path. You find yourself wandering along a dark walkway made of dirt. It is lined with jagged overhanging tree branches, the ground beside you scattered with dark patches of thorny shrubbery. As the day begins to end, the only source of light you have is the dim shine from the moon. Or so you thought. You see an ominous light in the distance somewhere in the woods. Do you want to INVESTIGATE it or IGNORE it and keep walking?";
    controlVar = "right";
  } else {
    // With no results, or bad results, repeat the question with more detail:
    storyOutput = "You come to a split in the woods. There are two paths. Do you want to take the LEFT path or the RIGHT path?";
  }
  updateStory();
}

//Right - Investigate / Ignore
function checkAnswerRight(){
  if (answer === "INVESTIGATE") {
    storyOutput = "You find a small opening in the side of the woods, and begin making your way towards the source of the mysterious light. Eventually you find yourself looking at a small campsite, with a large pool of a dark red substance sitting on the ground near one of the tents. Would you like to LEAVE the woods and go back home, or EXAMINE the liquid?";
    controlVar = "investigate1";
  } else if (answer === "IGNORE") {
    storyOutput = "You continue your journey along the path, only to find yourself in the center of many hungry looking Anthony Sergios. You gulp as they begin uselessly prodding you with their toothpicks. You shrivel up and go to sleep because you’re too tired to deal with his shenanigans. The end, you got the TONY ENDING.";
    controlVar = "start";
  } else {
    //With no results, or bad results, repeat the question with more detail:
    storyOutput = "You decide to go down the RIGHT path. You find yourself wandering along a dark walkway made of dirt. It is lined with jagged overhanging tree branches, the ground beside you scattered with dark patches of thorny shrubbery. As the day begins to end, the only source of light you have is the dim shine from the moon. Or so you thought. You see an ominous light in the distance somewhere in the woods. Do you want to INVESTIGATE it or IGNORE it and keep walking?";
  }
  updateStory();
}

//Investigate - Leave / Examine
function checkAnswerInvestigate1(){
  if (answer === "LEAVE") {
    storyOutput = "You try to escape, and manage to. You get back to your house and jump under the covers. You see a blindingly bright light coming from your window, and reach out to it. Jesus Christ Almighty makes his way through your bedroom window and delivers a rock hard SLAP right across your face, telling you how guilty your conscious is. The end, you got the HOLY LORD ENDING.";
    controlVar = "start";
  } else if (answer === "EXAMINE") {
    storyOutput = "You creep your way towards the substance, and roll your eyes at the large pile of strawberry jam jars that lay beside the jam. You think to yourself, “What a waste,” and pick them all up. You make sure everything is all nice and tidy before leaving the area and returning back home to properly get rid of the jars. You go to bed knowing what a wonderfully person you are. The end, you got the KIND SAMARITAN ENDING.";
    controlVar = "start";
  } else {
    //With no results, or bad results, repeat the question with more detail:
    storyOutput = "You find a small opening in the side of the woods, and begin making your way towards the source of the mysterious light. Eventually you find yourself looking at a small campsite, with a large pool of a dark red substance sitting on the ground near one of the tents. Would you like to LEAVE the woods and go back home, or EXAMINE the liquid?";
  }
  updateStory();
}

//Left - Enter / Observe
function checkAnswerLeft(){
  if (answer === "ENTER") {
    storyOutput = "You gather enough guts to make yourself stand and start towards the village. As you get closer and closer, your ears are filled with the sounds of laughing and music. You reach the village, and see a couple different buildings. Your nose is delightfully overwhelmed by the scent of baked goods, and you start looking around for the source. You find yourself at the door of a bakery. Do you want to go INSIDE or ignore your cravings and CONTINUE looking around?";
    controlVar = "enter";
  } else if (answer === "OBSERVE") {
    storyOutput = "You don’t want to take any risks, so you stay where you are and continue to look over the village for any details you may have missed. You notice something a couple hundred feet away, behind one of the village houses closer to the forest. Do you want to INVESTIGATE it or IGNORE it and continue observing?";
    controlVar = "observe";
  } else {
    //With no results, or bad results, repeat the question with more detail:
    storyOutput = "You decide to take the LEFT path. The dirt road soon turns into a crunchy path of shiny gravel. It feels a little wet beneath your bare feet. Soothing, in a way. But this feeling of relaxation doesn’t last long, being replaced by a feeling of curiosity as you come across what looks to be a small village filled with busy people. You can’t shake the feeling that something is wrong. Do you want to ENTER the village, or stay where you are and see if you can OBSERVE anything suspicious?";
  }
  updateStory();
}

//Enter - Inside / Continue
function checkAnswerEnter(){
  if (answer === "INSIDE") {
    storyOutput = "You impatiently swing the door open and enter the bakery. You check yourself for any money in your pockets, but find none. You see a particularly delicious looking cake. Do you STEAL it or go back HOME?";
    controlVar = "inside";
  } else if (answer === "CONTINUE") {
    storyOutput = "You CONTINUE your journey and make your way further into the village. People’s heads turned towards you and your life flashes before you as they all synchronously start running at you, wielding pitchforks. They were screaming “Outsider! Be gone with the different!” And then you got poked to death. The end, you got the ANGRY MOB ENDING.";
    controlVar = "start";
  } else {
    //With no results, or bad results, repeat the question with more detail:
    storyOutput = "You gather enough guts to make yourself stand and start towards the village. As you get closer and closer, your ears are filled with the sounds of laughing and music. You reach the village, and see a couple different buildings. Your nose is delightfully overwhelmed by the scent of baked goods, and you start looking around for the source. You find yourself at the door of a bakery. Do you want to go INSIDE or ignore your cravings and CONTINUE looking around?";
  }
  updateStory();
}

//Inside - Steal / Home
function checkAnswerInside(){
  if (answer === "STEAL") {
    storyOutput = "You STEAL the cake and run out the door. You are met with the angry Italian face of the chef. He beats you to a plumb with his whisk. You die. The end, you got the SWIPER NO SWIPING ENDING.";
    controlVar = "start";
  } else if (answer === "HOME") {
    storyOutput = "You walk HOME, all sad and depressed, because you couldn’t get your cake. “Boohoo,” you cry to yourself as you ponder the thoughts of not being able to taste the sensation that is cake taste. The end, you got the CRY ABOUT IT ENDING.";
    controlVar = "start";
  } else {
    //With no results, or bad results, repeat the question with more detail:
    storyOutput = "You impatiently swing the door open and enter the bakery. You check yourself for any money in your pockets, but find none. You see a particularly delicious looking cake. Do you STEAL it or go back HOME?";
  }
  updateStory();
}

//Observe - Investigate / Ignore
function checkAnswerObserve(){
  if (answer === "INVESTIGATE") {
    storyOutput = "You find a pile of dead flowers. You throw up from the nauseating sight. You die. The end, you got the WHAT THE FRACK ENDING.";
    controlVar = "start";
  } else if (answer === "IGNORE") {
    storyOutput = "You stay put, and continue to scout the area. You see a frog jumping off of what looks to be an animal skin. Do you want to INVESTIGATE or IGNORE it and stay where you are?";
    controlVar = "ignore";
  } else {
    //With no results, or bad results, repeat the question with more detail:
    storyOutput = "You don’t want to take any risks, so you stay where you are and continue to look over the village for any details you may have missed. You notice something a couple hundred feet away, behind one of the village houses closer to the forest. Do you want to INVESTIGATE it or IGNORE it and continue observing?";
  }
  updateStory();
}

//Ignore - Investigate / Ignore
function checkAnswerIgnore(){
  if (answer === "INVESTIGATE"){
    storyOutput = "You go to the mysterious sight, and find that it is not what it seems, but rather just a wet welcome mat that was hung to dry. You look around to see if anyone was watching your stupidity, and are a bit too late to see the large figure’s fist coming towards your face. You eventually wake up in a small prison cell, where you are met with the tightness of the ropes that are holding your legs to the chair. A man is across from you holding a box out towards you. Do you TAKE the box and open it, or REFUSE it?";
    controlVar = "investigate2";
  } else if (answer === "IGNORE"){
    storyOutput = "You choose to IGNORE it, and die of boredom because you’ve sat here for the past three hours. The end, you got the BOREDOM ENDING.";
    controlVar = "start";
  } else {
    //With no results, or bad results, repeat the question with more detail:
    storyOutput = "You stay put, and continue to scout the area. You see a frog jumping off of what looks to be an animal skin. Do you want to INVESTIGATE or IGNORE it and stay where you are?";
  }
  updateStory();
}

//Investigate - Refuse / Accept
function checkAnswerInvestigate2(){
  if (answer === "REFUSE") {
    storyOutput = "You do not take the box, and this seems to greatly anger the man holding it. His face quickly shifts to an expression of pure hatred, and he rips the lid off of the top of the box, revealing multiple snakes. He flings the box towards you, launching the snakes onto you, and you wince in pain as their venomous fangs sink into your body. You die. The end, you got the SNAKE ENDING.";
    controlVar = "start";
  } else if (answer === ACCEPT) {
    storyOutput = "You smile and take the box from the man, who smiles back at you. You nervously take off the lid, revealing a stuffed animal. You look up to thank the man but he is already gone. You look back down at the toy only to find its mouth wide open, revealing rows of sharp fangs. It launches itself onto your face, sinking its teeth into your flesh. It eats you. You die. The end, you got the UH OH ENDING.";
    controlVar = "start";
  } else {
    //With no results, or bad results, repeat the question with more detail:
    storyOutput = "You stay put, and continue to scout the area. You see a frog jumping off of what looks to be an animal skin. Do you want to INVESTIGATE or IGNORE it and stay where you are?";
  }
  updateStory();
}